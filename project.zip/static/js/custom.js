// 功能
$(document).ready(function() {
  var chatBtn = $('#chatBtn');
  var chatInput = $('#chatInput');
  var chatWindow = $('#chatWindow');

  // 存储对话信息,实现连续对话
  var messages = [];

  // 检查返回的信息是否是正确信息
  var resFlag = true

  // 创建自定义渲染器
  const renderer = new marked.Renderer();

  // 重写list方法
  renderer.list = function(body, ordered, start) {
    const type = ordered ? 'ol' : 'ul';
    const startAttr = (ordered && start) ? ` start="${start}"` : '';
    return `<${type}${startAttr}>\n${body}</${type}>\n`;
  };

  // 设置marked选项
  marked.setOptions({
    renderer: renderer,
    highlight: function (code, language) {
      const validLanguage = hljs.getLanguage(language) ? language : 'javascript';
      return hljs.highlight(code, { language: validLanguage }).value;
    }
  });


  // 转义html代码(对应字符转移为html实体)，防止在浏览器渲染
  function escapeHtml(html) {
    let text = document.createTextNode(html);
    let div = document.createElement('div');
    div.appendChild(text);
    return div.innerHTML;
  }
  
  // 添加请求消息到窗口
  function addRequestMessage(message) {
    $(".answer .tips").css({"display":"none"});    // 打赏卡隐藏
    chatInput.val('');
    let escapedMessage = escapeHtml(message);  // 对请求message进行转义，防止输入的是html而被浏览器渲染
    let requestMessageElement = $('<div class="message-bubble"><span class="chat-icon request-icon"></span><div class="message-text request"><p>' +  escapedMessage + '</p></div></div>');
    chatWindow.append(requestMessageElement);
    let responseMessageElement = $('<div class="message-bubble"><span class="chat-icon response-icon"></span><div class="message-text response"><span class="loading-icon"><i class="fa fa-spinner fa-pulse fa-2x"></i></span></div></div>');
    chatWindow.append(responseMessageElement);
    chatWindow.scrollTop(chatWindow.prop('scrollHeight'));
  }
  
  // 添加响应消息到窗口,流式响应此方法会执行多次
  function addResponseMessage(message) {
    let lastResponseElement = $(".message-bubble .response").last();
    lastResponseElement.empty();
    let escapedMessage;
    // 处理流式消息中的代码块
    let codeMarkCount = 0;
    let index = message.indexOf('```');
    while (index !== -1) {
        codeMarkCount ++ ;
        index = message.indexOf('```', index + 3);
    }
    if(codeMarkCount % 2 == 1  ){  // 有未闭合的 code
      escapedMessage = marked.parse(message + '\n\n```'); 
    }else if(codeMarkCount % 2 == 0 && codeMarkCount != 0){
      escapedMessage = marked.parse(message);  // 响应消息markdown实时转换为html
    }else if(codeMarkCount == 0){  // 输出的代码没有markdown代码块
      if (message.includes('`')){
        escapedMessage = marked.parse(message);  // 没有markdown代码块，但有代码段，依旧是markdown格式
      }else{
        escapedMessage = marked.parse(escapeHtml(message)); // 有可能不是markdown格式，都用escapeHtml处理后再转换，防止非markdown格式html紊乱页面
      }
    }
    lastResponseElement.append(escapedMessage);
    chatWindow.scrollTop(chatWindow.prop('scrollHeight'));
  }

  // 添加失败信息到窗口
  function addFailMessage(message) {
    let lastResponseElement = $(".message-bubble .response").last();
    lastResponseElement.empty();
    lastResponseElement.append('<p class="error">' + message + '</p>');
    chatWindow.scrollTop(chatWindow.prop('scrollHeight'));
    messages.pop() // 失败就让用户输入信息从数组删除
  }

  // 生成按钮 HTML
  function generateButtonsHtml() {
    // 计算昨天的日期
    let yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    let year = yesterday.getFullYear();
    let month = yesterday.getMonth() + 1;
    let day = yesterday.getDate();
    let dateStr = year + "年" + month + "月" + day + "日";
    
    return '<div class="welcome-btn-group">' +
        '<button class="welcome-btn" onclick="sendWelcomeMsg(\'生成昨天的核聚变资讯报告\')">生成昨天的核聚变资讯报告</button>' +
        '<button class="welcome-btn" onclick="sendWelcomeMsg(\'生成' + dateStr + '的聚变资讯报告\')">生成' + dateStr + '的聚变资讯报告</button>' +
        '<button class="welcome-btn" onclick="sendWelcomeMsg(\'生成最新的聚变资讯报告\')">生成最新的聚变资讯报告</button>' +
      '</div>' +
      '<div class="welcome-btn-group">' +
        '<button class="welcome-btn" onclick="appendParamToInput(\' results_per_keyword=5,keywords_per_batch=5 \')">标准</button>' +
        '<button class="welcome-btn" onclick="appendParamToInput(\' results_per_keyword=10,keywords_per_batch=8 \')">中等</button>' +
        '<button class="welcome-btn" onclick="appendParamToInput(\' results_per_keyword=30,keywords_per_batch=10 \')">最大</button>' +
      '</div>';
  }

  // 添加欢迎消息
  function addWelcomeMessage() {
    let welcomeText = "👋 你好！我是可控核聚变领域专业资讯报告生成助手。\n\n我可以为您提供最新的聚变资讯、生成专业报告，或回答相关技术问题。请直接在下方输入您的需求。";
    let escapedMessage = marked.parse(welcomeText);
    
    let welcomeElement = $('<div class="message-bubble"><span class="chat-icon response-icon"></span><div class="message-text response">' + escapedMessage + 
      generateButtonsHtml() +
    '</div></div>');
    
    chatWindow.append(welcomeElement);
    $(".answer .tips").hide();
    chatWindow.scrollTop(chatWindow.prop('scrollHeight'));
  }

  // 暴露给全局的点击填充函数（仅填充不发送）
  window.sendWelcomeMsg = function(msg) {
    $('#chatInput').val(msg);
    // 聚焦输入框，方便用户直接修改或发送
    $('#chatInput').focus();
    // 自动调整输入框高度（如果有自动高度调整逻辑的话，触发 input 事件）
    $('#chatInput').trigger('input');
  };

  // 暴露给全局的参数追加函数（追加到输入框内容后）
  window.appendParamToInput = function(param) {
    let currentVal = $('#chatInput').val();
    $('#chatInput').val(currentVal + param);
    // 聚焦输入框
    $('#chatInput').focus();
    // 自动调整输入框高度
    $('#chatInput').trigger('input');
  };
  

  // 发送请求获得响应
  async function sendRequest(data) {
    const payload = {
      "content": { 
        "query": { 
          "prompt": [ 
            { 
              "type": "text", 
              "content": { 
                "text": data.prompt
              } 
            } 
          ] 
        } 
      }, 
      "type": "query", 
      "session_id": data.sessionId || "Zi4LBPNkYykLfCIeTuuK4", 
      "project_id": config.projectId 
    };

    // Ensure project_id is sent as a number if it's stored as a string
    let bodyStr = JSON.stringify(payload);
    bodyStr = bodyStr.replace(/"project_id":"(\d+)"/, '"project_id":$1');

    const response = await fetch(config.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + data.apiKey
      },
      body: bodyStr
    }); 
  
    const reader = response.body.getReader();
    let res = '';
    let str = '';
    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        break;
      }
      res += new TextDecoder().decode(value);
      const lines = res.split('\n');
      res = lines.pop(); // Keep the last incomplete line
      
      for (let i = 0; i < lines.length; i++) {
        let line = lines[i].trim();
        if (!line) continue;
        
        // Handle SSE format
        if (line.startsWith('event:')) continue; // Skip event lines
        if (line.startsWith('data:')) {
            line = line.substring(5).trim();
        }
        
        let jsonObj;
        try{
          jsonObj = JSON.parse(line);
        }catch(e){
          console.log('Error parsing JSON:', line);
          continue;
        }

        // Handle Coze streaming response
        // data: {"type": "answer", "content": {"answer": "..."}}
        if (jsonObj.type === 'answer' && jsonObj.content && typeof jsonObj.content.answer === 'string') {
             str += jsonObj.content.answer;
             addResponseMessage(str);
             resFlag = true;
        } 
        // Handle message_start or other control events (ignore content.answer if null)
        else if (jsonObj.type === 'message_start' || jsonObj.type === 'message_end') {
             // Do nothing or show status
        }
        // Fallback for other formats or legacy
        else if (typeof jsonObj.content === 'string') {
             str += jsonObj.content;
             addResponseMessage(str);
             resFlag = true;
        } else if (jsonObj.data && typeof jsonObj.data.content === 'string') {
             str += jsonObj.data.content;
             addResponseMessage(str);
             resFlag = true;
        } else if (jsonObj.message && typeof jsonObj.message === 'string') {
             str += jsonObj.message;
             addResponseMessage(str);
             resFlag = true;
        } else if (jsonObj.delta) { 
             str += jsonObj.delta;
             addResponseMessage(str);
             resFlag = true;
        }
        
        if(jsonObj.error){
            addFailMessage(jsonObj.error.message || "Error occurred");
            resFlag = false;
        }
        // Log for debugging
        console.log('Stream chunk:', jsonObj);
      }
    }
    return str;
  }

  // 处理用户输入
  chatBtn.click(function() {
    // 解绑键盘事件
    chatInput.off("keydown",handleEnter);
    
    // 保存api key与对话数据
    let data = {};
    if(config.apiKey !== ''){
      data.apiKey = config.apiKey; 
    }else{
      data.apiKey = "";
    }
   
    let apiKey = localStorage.getItem('apiKey');
    if (apiKey){
      data.apiKey = apiKey;
    }

    let message = chatInput.val();
    if (message.length == 0){
      // 重新绑定键盘事件
      chatInput.on("keydown",handleEnter);
      return
    }

    addRequestMessage(message);
    // 将用户消息保存到数组
    messages.push({"role": "user", "content": message})
    // 收到回复前让按钮不可点击
    chatBtn.attr('disabled',true)

    data.prompt = message;
      
    sendRequest(data).then((res) => {
      chatInput.val('');
      // 收到回复，让按钮可点击
      chatBtn.attr('disabled',false)
      // 重新绑定键盘事件
      chatInput.on("keydown",handleEnter); 
      // 判断是否是回复正确信息
      if(resFlag){
        // 在 AI 回复内容后追加快捷按钮
        let responseContent = res;
        // 如果想在页面显示的最后一条消息加按钮，需要操作 DOM，因为 res 只是文本内容
        // 这里我们重新构建一条带按钮的消息对象存入历史记录（可选），或者只在页面追加
        
        // 找到最后一条 AI 回复的 DOM 元素，追加按钮
        let lastResponseElement = $(".message-bubble .response").last();
        lastResponseElement.append(generateButtonsHtml());
        
        messages.push({"role": "assistant", "content": res});
        // 判断是否本地存储历史会话
        if(localStorage.getItem('archiveSession')=="true"){
          localStorage.setItem("session",JSON.stringify(messages));
        }
      }
      // 添加复制
      copy();
    });
  });  

  // Enter键盘事件
  function handleEnter(e){
    if (e.keyCode==13){
      chatBtn.click();
      e.preventDefault();  //避免回车换行
    }
  }

  // 绑定Enter键盘事件
  chatInput.on("keydown",handleEnter);


  // 设置栏宽度自适应
  let width = $('.function .others').width();
  $('.function .settings .dropdown-menu').css('width', width);
  
  $(window).resize(function() {
    width = $('.function .others').width();
    $('.function .settings .dropdown-menu').css('width', width);
  });

  
  // 主题
  function setBgColor(theme){
    $(':root').attr('bg-theme', theme);
    $('.settings-common .theme').val(theme);
    // 定位在文档外的元素也同步主题色
    $('.settings-common').css('background-color', 'var(--bg-color)');
  }
  
  let theme = localStorage.getItem('theme');
  // 如果之前选择了主题，则将其应用到网站中
  if (theme) {
    setBgColor(theme);
  }else{
    localStorage.setItem('theme', "light"); //默认的主题
    theme = localStorage.getItem('theme');
    setBgColor(theme);
  }

  // 监听主题选择的变化
  $('.settings-common .theme').change(function() {
    const selectedTheme = $(this).val();
    localStorage.setItem('theme', selectedTheme);
    $(':root').attr('bg-theme', selectedTheme);
    // 定位在文档外的元素也同步主题色
    $('.settings-common').css('background-color', 'var(--bg-color)');
  });

  // apiKey
  const apiKey = localStorage.getItem('apiKey');
  if (apiKey) {
    $(".settings-common .api-key").val(apiKey);
  }

  // apiKey输入框事件
  $(".settings-common .api-key").blur(function() { 
    const apiKey = $(this).val();
    if(apiKey.length!=0){
      localStorage.setItem('apiKey', apiKey);
    }else{
      localStorage.removeItem('apiKey');
    }
  })

  // 是否保存历史对话
  var archiveSession = localStorage.getItem('archiveSession');

  // 初始化archiveSession
  if(archiveSession == null){
    archiveSession = "false";
    localStorage.setItem('archiveSession', archiveSession);
  }
  
  if(archiveSession == "true"){
    $("#chck-1").prop("checked", true);
  }else{
    $("#chck-1").prop("checked", false);
  }

  $('#chck-1').click(function() {
    if ($(this).prop('checked')) {
      // 开启状态的操作
      localStorage.setItem('archiveSession', true);
      if(messages.length != 0){
        localStorage.setItem("session",JSON.stringify(messages));
      }
    } else {
      // 关闭状态的操作
      localStorage.setItem('archiveSession', false);
      localStorage.removeItem("session");
    }
  });
  
  // 加载历史保存会话
  if(archiveSession == "true"){
    const messagesList = JSON.parse(localStorage.getItem("session"));
    if(messagesList){
      messages = messagesList;
      $.each(messages, function(index, item) {
        if (item.role === 'user') {
          addRequestMessage(item.content)
        } else if (item.role === 'assistant') {
          addResponseMessage(item.content)
        }
      });
      // 添加复制
      copy();
    }
  }

  // 如果没有历史记录，显示欢迎语
  if (messages.length === 0) {
    addWelcomeMessage();
  }

  // 是否连续对话
  var continuousDialogue = localStorage.getItem('continuousDialogue');

  // 初始化continuousDialogue
  if(continuousDialogue == null){
    continuousDialogue = "true";
    localStorage.setItem('continuousDialogue', continuousDialogue);
  }
  
  if(continuousDialogue == "true"){
    $("#chck-2").prop("checked", true);
  }else{
    $("#chck-2").prop("checked", false);
  }

  $('#chck-2').click(function() {
    if ($(this).prop('checked')) {
      localStorage.setItem('continuousDialogue', true);
    } else {
      localStorage.setItem('continuousDialogue', false);
    }
  });

  // 删除功能
  $(".delete a").click(function(){
    chatWindow.empty();
    messages = [];
    localStorage.removeItem("session");
    addWelcomeMessage();
  });

  // 截图功能
  $(".screenshot a").click(function() {
    // 创建副本元素
    const clonedChatWindow = chatWindow.clone();
    clonedChatWindow.css({
      position: "absolute",
      left: "-9999px",
      overflow: "visible",
      width: chatWindow.width(),
      height: "auto"
    });
    $("body").append(clonedChatWindow);
    // 截图
    html2canvas(clonedChatWindow[0], {
      allowTaint: false,
      useCORS: true,
      scrollY: 0,
    }).then(function(canvas) {
      // 将 canvas 转换成图片
      const imgData = canvas.toDataURL('image/png');
      // 创建下载链接
      const link = document.createElement('a');
      link.download = "screenshot_" + Math.floor(Date.now() / 1000) + ".png";
      link.href = imgData;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      clonedChatWindow.remove();
    });
  });

  // 复制代码功能
  function copy(){
    $('pre').each(function() {
      let btn = $('<button class="copy-btn">复制</button>');
      $(this).append(btn);
      btn.hide();
    });

    $('pre').hover(
      function() {
        $(this).find('.copy-btn').show();
      },
      function() {
        $(this).find('.copy-btn').hide();
      }
    );
  
    $('pre').on('click', '.copy-btn', function() {
      let text = $(this).siblings('code').text();
      // 创建一个临时的 textarea 元素
      let textArea = document.createElement("textarea");
      textArea.value = text;
      document.body.appendChild(textArea);

      // 选择 textarea 中的文本
      textArea.select();

      // 执行复制命令
      try {
        document.execCommand('copy');
        $(this).text('复制成功');
      } catch (e) {
        $(this).text('复制失败');
      }

      // 从文档中删除临时的 textarea 元素
      document.body.removeChild(textArea);

      setTimeout(() => {
        $(this).text('复制');
      }, 2000);
    });
  }

  // 禁用右键菜单
  document.addEventListener('contextmenu',function(e){
    e.preventDefault();  // 阻止默认事件
  });

  // 禁止键盘F12键
  // document.addEventListener('keydown',function(e){
  //   if(e.key == 'F12'){
  //       e.preventDefault(); // 如果按下键F12,阻止事件
  //   }
  // });
});